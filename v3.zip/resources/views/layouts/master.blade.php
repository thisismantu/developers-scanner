<!DOCTYPE html>
<html>

<head>
    <title>Laravel Inertia</title>
    @vite('resources/js/app.js')
</head>

<body>
    @inertia
</body>

</html>
