<?php

namespace App\Service;

class ApiService
{
    public function login()
    {
        // Implementation here
    }

    public function register()
    {
        // Implementation here
    }

    public function project()
    {
        // Implementation here
    }

    public function scan()
    {
        // Implementation here
    }

    public function status()
    {
        // Implementation here
    }

    public function reports()
    {
        // Implementation here
    }
}
