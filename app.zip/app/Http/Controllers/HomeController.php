<?php

namespace App\Http\Controllers;
use App\Models\Company;
use App\Models\Project;
use App\Models\ProjectMapping;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;

class HomeController extends Controller
{
    public function index()
    {
        $projects = ProjectMapping::whereUserId(Auth::id())->get();
        $users = User::whereIsAdmin(1)->get();
        $companies = Company::whereUserId(Auth::id())->get();
        return view('dashboard',compact('projects','users','companies'));
    }
}
